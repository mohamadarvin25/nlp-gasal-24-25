# NLP - Lab Task 4
Develop N-gram Language Model for NLP - Lab Task 4

### How to start
```
python -m venv env
source env/Scripts/activate

pip install -r requirements.txt
python main.py
```

### TODO
- None

### Done ✓
- [x] implement each preprocess step 21/9/24
- [x] implement train:val:test data split 21/9/24
- [x] implement bundled preprocess method 21/9/24
- [x] implement store data as byte in file 21/9/24
- [x] implement n-gram language model 21/9/24
- [x] Implement one door access 21/9/24
- [x] Report to the lecturer 21/9/24
- [x] Revised based on the given feedback xx/9/24

import math
import preprocess_data
from itertools import chain

class NgramModel:
  def __init__(self, vocab: list[str], train: list[list[str]], test: list[list[str]]) -> None:
    self.vocab = vocab
    self.train = train
    self.test = test
  
  def generate_n_grams(self, data: list[list[str]], n: int, start_token: str = '<s>', end_token='</s>') -> dict:
    self.train = data
    dict_n_grams = dict()
    for sentence in data:
      sentence = tuple([start_token] * n + sentence + [end_token])
      for idx in range(len(sentence)):
        token = sentence[idx:idx + n]
        if token in dict_n_grams:
          dict_n_grams[token] += 1
        else:
          dict_n_grams[token] = 1
    return dict_n_grams
  
  def count_probability(self, predicted_word: str, given_word: list[str], n_gram_counts, n_plus1_gram_counts, vocabulary_size, laplace_number: float = 1.0) -> float:
    given_word = tuple(given_word)
    num_of_n_gram_of_given_word = n_gram_counts[given_word] if given_word in n_gram_counts else 0
    denominator = num_of_n_gram_of_given_word + laplace_number * vocabulary_size

    given_and_predicted_word = given_word + (predicted_word, )
    num_of_n_gram_of_combination = n_plus1_gram_counts[given_and_predicted_word] if given_and_predicted_word in n_plus1_gram_counts else 0
    numerator = num_of_n_gram_of_combination + laplace_number

    probability = numerator / denominator
    return probability
  
  def probabilities_for_all_vocab(self, given_word: list[str], n_gram_counts, n_plus1_gram_counts, vocabulary, end_token='</s>', unknown_token='<unk>',  laplace_number=1.0):
    given_word = tuple(given_word)
    vocabulary = vocabulary + [end_token, unknown_token]
    vocab_size = len(vocabulary)

    probs = dict()
    for word in vocabulary:
      prob = self.count_probability(word, given_word, n_gram_counts, n_plus1_gram_counts, vocab_size, laplace_number=laplace_number)
      probs[word] = prob
    return probs

  def count_perplexity(self, sentence, n_gram_counts, n_plus1_gram_counts, vocab_size, start_token='<s>', end_token = '</s>', laplace_number=1.0):
    n_gram_len = len(n_gram_counts) if isinstance(n_gram_counts, list) else len(list(n_gram_counts.keys())[0])
    sentence = [start_token] * n_gram_len + sentence + [end_token]
    sentence = tuple(sentence)
    final_len = len(sentence)

    sum_prob = 1.0
    for token in range(n_gram_len, final_len):
      n_gram = sentence[token-n_gram_len:token]
      word = sentence[token]
      prob = math.log2(self.count_probability(word, n_gram, n_gram_counts, n_plus1_gram_counts, vocab_size, laplace_number))
      sum_prob += prob
    perplexity = -1/final_len * sum_prob
    
    return perplexity

def main():
  lowercase: bool = False
  preprocess = preprocess_data.Preprocess()
  vocab, train, test = preprocess.load_from_pickle(lowercase)

  model = NgramModel(vocab, train, test)
  flatten_test = list(chain.from_iterable(test))

  unigram_counts = model.generate_n_grams(train, 1)
  bigram_counts = model.generate_n_grams(train, 2)
  trigram_counts = model.generate_n_grams(train, 3)

  print(f'Lowercase: {lowercase}')

  """
  EXAMPLE:
  - Di bawah ini merupakan contoh/cara untuk generate kalimat dari n-gram LM
  """

  """
  UNIGRAM
  """
  generate_S_unigram = model.probabilities_for_all_vocab(['saya'], train, unigram_counts, vocab)
  print(max(generate_S_unigram, key=generate_S_unigram.get))
  print(sorted(generate_S_unigram.items(), key=lambda x:x[1], reverse=True)[:5])

  """
  BIGRAM
  """
  generate_S_bigram = model.probabilities_for_all_vocab(['Berkas'], unigram_counts, bigram_counts, vocab)
  print(max(generate_S_bigram, key=generate_S_bigram.get))
  print(sorted(generate_S_bigram.items(), key=lambda x:x[1], reverse=True)[:5])

  """
  TRIGRAM
  """
  generate_S_trigram = model.probabilities_for_all_vocab(['pergi'], bigram_counts, trigram_counts, vocab)
  print(max(generate_S_trigram, key=generate_S_trigram.get))
  print(sorted(generate_S_trigram.items(), key=lambda x:x[1], reverse=True)[:5])


  """
  - Di bawah ini merupakan contoh/cara untuk menilai perplexity dari kalimat yang telah Anda generate dari langkah sebelumnya.
  """

  """
  UNIGRAM
  """
  perplexity_test_unigram = model.count_perplexity(flatten_test, train, unigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 1, Perplexity: {perplexity_test_unigram:.4f}")

  """
  BIGRAM
  """
  perplexity_test_bigram = model.count_perplexity(flatten_test, unigram_counts, bigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 2, Perplexity: {perplexity_test_bigram:.4f}")


  """
  TRIGRAM
  """
  perplexity_test_trigram = model.count_perplexity(flatten_test, bigram_counts, trigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 3, Perplexity: {perplexity_test_trigram:.4f}")

  """
  TRIGRAM from generated sentence
  """
  perplexity_test_random = model.count_perplexity(['<s>', 'cagar', 'budaya', 'merupakan', 'aset', 'di', 'indonesia', '</s>'], bigram_counts, trigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 3, Perplexity: {perplexity_test_random:.4f}")

  """
  Sentences from the problem set
  """
  perplexity_unigram_one = model.count_perplexity(['<s>', 'saya', 'sedang', 'menunggu', 'di', 'peron', '5', 'stasiun', 'tersebut', '</s>'], train, unigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 1, Perplexity: {perplexity_unigram_one:.4f}")

  perplexity_unigram_two = model.count_perplexity(['<s>', 'para', 'pekerja', 'terlihat', 'lincah', 'saat', 'membersihkan', 'lokomotif', 'tersebut', '</s>'], train, unigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 1, Perplexity: {perplexity_unigram_two:.4f}")

  perplexity_bigram_one = model.count_perplexity(['<s>', '<s>', 'pak', 'ustad', 'berceramah', 'di', 'atas', 'mimbar', 'masjid', '</s>'], unigram_counts, bigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 2, Perplexity: {perplexity_bigram_one:.4f}")

  perplexity_bigram_two = model.count_perplexity(['<s>', '<s>', 'para', 'murid', 'diajarkan', 'budi', 'pekerti', 'di', 'sekolah', '</s>'], unigram_counts, bigram_counts, len(vocab), laplace_number=1.0)
  print(f"n = 2, Perplexity: {perplexity_bigram_two:.4f}")

if __name__ == "__main__":
  main()

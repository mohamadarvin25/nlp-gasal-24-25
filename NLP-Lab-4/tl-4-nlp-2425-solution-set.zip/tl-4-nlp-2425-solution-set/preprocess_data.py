import pickle
import numpy as np
from aksara import BaseTokenizer

class Preprocess:
  def __init__(self) -> None:
    self.data: list[str] = None
    self.train_data: list[str] = None
    self.test_data: list[str] = None
  
  def load_data(self, path: str) -> None:
    with open(path, 'r', encoding='utf-8') as f:
      data = f.readlines()
    
    data_type = path.split('/')[-1].split('-')[-1].split('.')[0]
    if data_type == 'train':
      self.train_data = data
    elif data_type == 'test':
      self.test_data = data
  
  def get_train_data(self) -> list[str]:
    return self.train_data
  
  def get_test_data(self) -> list[str]:
    return self.test_data
  
  def split_sentences(self, data: list[str]) -> list[str]:
    data = [sentence.split('\n')[0] for sentence in data]
    data = [sentence.strip() for sentence in data]
    return data
  
  def tokenize_sentences(self, data: list[str], lower: bool) -> list[list[str]]:
    base_tokenizer = BaseTokenizer()
    cleaned: list[str] = []
    for sentence in data:
      lowered: str = sentence.lower()
      tokenized: list[str] = base_tokenizer.tokenize(lowered)[0]
      tokenized: list[str] = [token for token in tokenized if token.isascii()]
      cleaned.append(tokenized)
    return cleaned
  
  def get_tokenized_data(self, data: list[str], lower: bool) -> list[list[str]]:
    splitted: list[str] = self.split_sentences(data)
    tokenized: list[str] = self.tokenize_sentences(splitted, lower)
    return tokenized

  def word_map(self, data: list[list[str]]) -> dict:
    map = dict()
    for sentence in data:
      for word in sentence:
        if word not in map:
          map[word] = 1
        else:
          map[word] += 1
    return map
  
  def filter_vocab_by_threshold(self, data: list[list[str]], num_threshold: int) -> list[str]:
    map: dict = self.word_map(data)
    filtered = [word for word, num in map.items() if num >= num_threshold]
    return filtered
  
  def handle_oov_with_unk(self, data: list[list[str]], vocab: list[str], unknown_token='<unk>') -> list[list[str]]:
    vocab = set(vocab)
    data_handled: list[list[str]] = []
    for sentence in data:
      sentence_handled: list[str] = []
      for word in sentence:
        if word in vocab:
          sentence_handled.append(word)
        else:
          sentence_handled.append(unknown_token)
      data_handled.append(sentence_handled)
    return data_handled
  
  def preprocess_raw_data(self, train, test, threshold):
    vocab = self.filter_vocab_by_threshold(train, threshold)
    train_handled = self.handle_oov_with_unk(train, vocab)
    test_handled = self.handle_oov_with_unk(test, vocab)
    return vocab, train_handled, test_handled
  
  def save_to_pickle(self, vocab: list[str], train: list[list[str]], test: list[list[str]], lower: bool) -> None:
    filename = {'vocab': vocab, 'train': train, 'test': test}
    for key, value in filename.items():
      filename = f'./data/idwiki-{key}-uncased.pkl'
      if lower:
        filename = f'./data/idwiki-{key}-cased.pkl'
      with open(filename, 'wb+') as f:
        pickle.dump(value, f)
  
  def load_from_pickle(self, lower: bool):
    suffix = 'uncased'
    if lower:
      suffix = 'cased'
    with open(f'./data/idwiki-vocab-{suffix}.pkl', 'rb') as f:
      vocab = pickle.load(f)
    with open(f'./data/idwiki-train-{suffix}.pkl', 'rb') as f:
      train = pickle.load(f)
    with open(f'./data/idwiki-test-{suffix}.pkl', 'rb') as f:
      test = pickle.load(f)
    return vocab, train, test
  
def main():
  preprocess = Preprocess()
  print('Loading data...')
  preprocess.load_data('./processed_data/idwiki-train.txt')
  preprocess.load_data('./processed_data/idwiki-test.txt')

  train = preprocess.get_train_data()
  test = preprocess.get_test_data()

  lowercase: bool = False
  tokenized_train = preprocess.get_tokenized_data(train, lowercase)
  tokenized_test = preprocess.get_tokenized_data(test, lowercase)

  print('Pre-processing data...')
  vocab, train_handled, test_handled = preprocess.preprocess_raw_data(tokenized_train, tokenized_test, 3)

  print('Saving data...')
  preprocess.save_to_pickle(vocab, train_handled, test_handled, lowercase)
  print('Finish!')

if __name__ == "__main__":
  main()
